player_manager.AddValidModel( "Funny Rat", "models/akuld/funnyrat/rat.mdl" )
list.Set( "PlayerOptionsModel", "Funny Rat", "models/akuld/funnyrat/rat.mdl" )

player_manager.AddValidModel( "Funny Rat (Colorable)", "models/akuld/funnyrat/ratcolorable.mdl" )
list.Set( "PlayerOptionsModel", "Funny Rat (Colorable)", "models/akuld/funnyrat/ratcolorable.mdl" )

player_manager.AddValidHands( "Funny Rat", "models/akuld/funnyrat/ratarms.mdl", 0, "00000000" )
player_manager.AddValidHands( "Funny Rat (Colorable)", "models/akuld/funnyrat/ratarms_c.mdl", 0, "00000000" )